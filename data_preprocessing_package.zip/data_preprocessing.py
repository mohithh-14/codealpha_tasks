import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from scipy import stats

def load_data(file_path):
    """
    Load data from a CSV file
    """
    return pd.read_csv(file_path)

def handle_missing_values(df, strategy='mean'):
    """
    Handle missing values in the dataset
    Parameters:
    - df: pandas DataFrame
    - strategy: 'mean', 'median', 'most_frequent', or 'constant'
    """
    imputer = SimpleImputer(strategy=strategy)
    df_imputed = pd.DataFrame(imputer.fit_transform(df), columns=df.columns)
    return df_imputed

def detect_outliers(df, threshold=3):
    """
    Detect and handle outliers using z-score method
    Parameters:
    - df: pandas DataFrame
    - threshold: z-score threshold for outlier detection
    """
    z_scores = np.abs(stats.zscore(df))
    outliers = (z_scores > threshold).any(axis=1)
    return df[~outliers]

def scale_features(df, method='standard'):
    """
    Scale features using either standardization or normalization
    Parameters:
    - df: pandas DataFrame
    - method: 'standard' for standardization or 'minmax' for normalization
    """
    if method == 'standard':
        scaler = StandardScaler()
    else:
        scaler = MinMaxScaler()
    
    scaled_data = scaler.fit_transform(df)
    return pd.DataFrame(scaled_data, columns=df.columns), scaler

def preprocess_data(file_path, target_column=None, test_size=0.2, random_state=42):
    """
    Complete data preprocessing pipeline
    Parameters:
    - file_path: path to the data file
    - target_column: name of the target column (if supervised learning)
    - test_size: proportion of data to use for testing
    - random_state: random seed for reproducibility
    """
    # Load data
    df = load_data(file_path)
    
    # Separate features and target if target column is specified
    if target_column:
        X = df.drop(columns=[target_column])
        y = df[target_column]
    else:
        X = df
        y = None
    
    # Handle missing values
    X_imputed = handle_missing_values(X)
    
    # Detect and remove outliers
    X_clean = detect_outliers(X_imputed)
    
    # Scale features
    X_scaled, scaler = scale_features(X_clean)
    
    # Split data if target is provided
    if y is not None:
        # Align y with cleaned X
        y_clean = y[X_clean.index]
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y_clean, test_size=test_size, random_state=random_state
        )
        return X_train, X_test, y_train, y_test, scaler
    else:
        return X_scaled, scaler

# Example usage
if __name__ == "__main__":
    print("Starting data preprocessing...")
    
    # Process data with target column
    print("\nProcessing data with target column:")
    X_train, X_test, y_train, y_test, scaler = preprocess_data(
        'sample_data.csv',
        target_column='target',
        test_size=0.2
    )
    
    print("\nTraining set shape:", X_train.shape)
    print("Testing set shape:", X_test.shape)
    print("\nFirst few rows of scaled training data:")
    print(X_train.head())
    print("\nFirst few rows of training labels:")
    print(y_train.head())
    
    # Process data without target column
    print("\nProcessing data without target column:")
    X_scaled, scaler = preprocess_data('sample_data.csv')
    print("\nScaled data shape:", X_scaled.shape)
    print("\nFirst few rows of scaled data:")
    print(X_scaled.head()) 