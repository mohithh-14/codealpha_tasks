# Data Preprocessing Package

This package provides a comprehensive data preprocessing pipeline for machine learning tasks. It handles missing values, outliers, feature scaling, and data splitting.

## Features

- Missing value handling using multiple strategies (mean, median, most frequent, constant)
- Outlier detection and removal using z-score method
- Feature scaling (Standardization and MinMax scaling)
- Train-test splitting for supervised learning tasks

## Requirements

- Python 3.x
- pandas
- numpy
- scikit-learn
- scipy

## Installation

1. Install the required packages:
```bash
pip install -r requirements.txt
```

## Usage

1. Import the preprocessing functions:
```python
from data_preprocessing import preprocess_data
```

2. For supervised learning (with target column):
```python
X_train, X_test, y_train, y_test, scaler = preprocess_data(
    'your_data.csv',
    target_column='target',
    test_size=0.2
)
```

3. For unsupervised learning (without target column):
```python
X_scaled, scaler = preprocess_data('your_data.csv')
```

## Parameters

- `file_path`: Path to your data file (CSV format)
- `target_column`: Name of the target column (optional)
- `test_size`: Proportion of data to use for testing (default: 0.2)
- `random_state`: Random seed for reproducibility (default: 42)

## Example

See `sample_data.csv` for an example dataset and `data_preprocessing.py` for implementation details. 